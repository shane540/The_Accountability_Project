# The Accountability Project — Setup Guide

## Files in This Package

| File | Purpose |
|------|---------|
| `accountability_project.html` | Main app — politician tracker, recall tool, report form |
| `statewide_officers.html` | All 50 states — governor + statewide officer removal |
| `federal_officers.html` | Federal removal tools, strategy, action checklist |
| `api_integration.js` | Live data integration — FEC + ProPublica APIs |
| `SETUP_GUIDE.md` | This file |

---

## Step 1 — Get Live on the Internet (10 minutes, free)

### Option A — Netlify (easiest)
1. Go to **netlify.com/drop**
2. Drag your entire folder into the browser window
3. Done — you get a live URL instantly
4. Optional: connect a custom domain in Netlify settings

### Option B — GitHub Pages (free, permanent)
1. Create a free account at github.com
2. Create a new repository named `accountability-project`
3. Upload all four files
4. Go to Settings → Pages → Source: main branch
5. Live at `yourusername.github.io/accountability-project`

### Option C — Cloudflare Pages (fastest CDN, free)
1. Push files to a GitHub repo
2. Go to pages.cloudflare.com
3. Connect GitHub repo — auto-deploys on every update

---

## Step 2 — Get Your API Keys

### FEC API Key (free, instant)
1. Go to: **https://api.data.gov/signup/**
2. Enter your email address
3. Key arrives in your inbox immediately
4. Open `api_integration.js`
5. Replace `YOUR_FEC_API_KEY_HERE` with your key

### ProPublica Congress API Key (free, 1-2 days)
1. Go to: **https://www.propublica.org/datastore/api/propublica-congress-api**
2. Fill out the request form
3. Key arrives by email within a few days
4. Replace `YOUR_PROPUBLICA_KEY_HERE` in `api_integration.js`

---

## Step 3 — Wire the API into the App

Add this single line to `accountability_project.html` just before the closing `</body>` tag:

```html
<script src="api_integration.js"></script>
```

Then to load a real politician, add this anywhere in your app JavaScript:

```javascript
// Load a single politician by name and state
const data = await AccountabilityAPI.loadPolitician('Jim Jordan', 'OH', 'H');

// Load all Congress members from Ohio
const ohioReps = await AccountabilityAPI.loadStateMembers('OH');

// Add live card to the tracker
const card = await AccountabilityAPI.renderLiveCard('Jim Jordan', 'OH', 'H');
if (card) { politicians.push(card); renderCards(); }
```

Office codes: `H` = House, `S` = Senate, `P` = President

---

## Step 4 — Add Violation Reporting Backend (optional)

The report form currently logs submissions to the console. To store them, add one of these free backends:

### Option A — Formspree (easiest, free tier)
1. Go to **formspree.io** — create free account
2. Create a new form — get a form endpoint URL
3. In `accountability_project.html`, find `submitReport()` function
4. Replace the console.log with:
```javascript
await fetch('https://formspree.io/f/YOUR_FORM_ID', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({ name, state, type, desc, evidence, reporter })
});
```

### Option B — Airtable (free, 1200 records)
1. Create free Airtable account at **airtable.com**
2. Create a base with fields: Name, State, Office, Type, Description, Evidence, Date
3. Get your API key from airtable.com/account
4. Use Airtable API to POST new records on submission

### Option C — Google Sheets via Google Apps Script (free, unlimited)
1. Create a Google Sheet with matching columns
2. Tools → Script Editor — create a doPost() web app
3. Deploy as web app — get URL
4. POST to that URL from submitReport()

---

## Step 5 — Add Real Violation Data

The tracker currently has sample politicians. To add real ones:

### Manual method (fast)
Edit the `politicians` array in `accountability_project.html`.
Each entry follows this structure:

```javascript
{
  id: 7,
  name: "Your Politician Name",
  party: "R",  // R, D, or I
  state: "Ohio",
  office: "U.S. Representative",
  level: "federal",  // federal or state
  since: 2020,
  violations: 3,
  totalDonors: "$1.2M",
  recallActive: false,
  threatScore: 75,
  donors: [
    { name: "Donor PAC Name", amount: "$500,000", industry: "Energy" },
  ],
  violations_list: [
    { type: "Campaign Finance", desc: "Description of violation", date: "2024" },
  ]
}
```

### API method (automatic)
Use `AccountabilityAPI.renderLiveCard()` — pulls real donor data from FEC automatically.

---

## Data Sources

| Source | Data | Update Frequency | Cost |
|--------|------|-----------------|------|
| OpenFEC API | Campaign finance, donors, PACs | Every 15 min (electronic) | Free |
| ProPublica Congress API | Voting records, bio, committees | Daily | Free |
| OpenSecrets | Lobbying, industry breakdown | Weekly | Free (limited) |
| PACER | Federal court records | Real-time | $0.10/page |
| GovTrack | Voting records | Real-time | Free |

---

## Legal Notes

- All data displayed is from public records
- FEC data is public domain
- ProPublica API is Creative Commons Attribution-NonCommercial
- Violation reports submitted by users should be clearly labeled as unverified until confirmed
- Add a disclaimer: "Violation reports are citizen-submitted and unverified unless noted"
- This tool facilitates access to public information and legal filing processes — all actions described are legal

---

## What's Next — Full Production Build

To go from this to a full production app you need:

1. **Backend API** — Node.js/Express or Python/FastAPI to proxy API calls (hides your API keys)
2. **Database** — PostgreSQL or Supabase to store reports and politician data
3. **Authentication** — For verified reporters and admin access
4. **Real-time updates** — WebSockets or polling for live recall signature counts
5. **Search indexing** — Elasticsearch for fast politician search across all 535 members

Estimated build time with a developer: 2-4 weeks for full production.
Estimated cost hosting: $20-50/month on Render or Railway.

---

*The Accountability Project — Built to scare them straight.*
